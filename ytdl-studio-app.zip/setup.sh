#!/usr/bin/env bash
#
# setup.sh — one-shot setup for YTDL Studio.
#
# What it does:
#   1. Checks for Python 3.9+
#   2. Creates a venv in backend/.venv (so this doesn't touch your system Python)
#   3. Installs backend/requirements.txt into that venv
#   4. Checks for ffmpeg on PATH; installs it if it can (apt/brew/dnf/pacman),
#      otherwise tells you exactly what to do
#   5. Optionally starts the server (asks first, or pass --run to skip asking)
#
# Usage:
#   ./setup.sh            # set up, then ask whether to start the server
#   ./setup.sh --run      # set up, then start the server immediately
#   ./setup.sh --no-run   # set up only, don't start or ask

set -euo pipefail

# ---------- pretty output ----------
BOLD=$'\033[1m'; DIM=$'\033[2m'; RED=$'\033[31m'; GREEN=$'\033[32m'; YELLOW=$'\033[33m'; RESET=$'\033[0m'
info()  { echo "${BOLD}▸${RESET} $*"; }
ok()    { echo "${GREEN}✓${RESET} $*"; }
warn()  { echo "${YELLOW}!${RESET} $*"; }
fail()  { echo "${RED}✗${RESET} $*" >&2; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKEND_DIR="$SCRIPT_DIR/backend"
VENV_DIR="$BACKEND_DIR/.venv"

RUN_MODE="ask"
for arg in "${@:-}"; do
  case "$arg" in
    --run) RUN_MODE="yes" ;;
    --no-run) RUN_MODE="no" ;;
  esac
done

echo "${BOLD}YTDL Studio — setup${RESET}"
echo "${DIM}$SCRIPT_DIR${RESET}"
echo ""

# ---------- 1. Python ----------
info "Checking for Python 3..."
PYTHON_BIN=""
for cand in python3 python; do
  if command -v "$cand" >/dev/null 2>&1; then
    ver="$("$cand" -c 'import sys; print("%d.%d" % sys.version_info[:2])' 2>/dev/null || echo "0.0")"
    major="${ver%%.*}"; minor="${ver##*.}"
    if [ "$major" -eq 3 ] && [ "$minor" -ge 9 ]; then
      PYTHON_BIN="$cand"
      break
    fi
  fi
done
if [ -z "$PYTHON_BIN" ]; then
  fail "Python 3.9+ not found. Install it first: https://www.python.org/downloads/"
fi
ok "Using $($PYTHON_BIN --version) ($PYTHON_BIN)"

# ---------- 2. venv ----------
if [ ! -d "$VENV_DIR" ]; then
  info "Creating virtual environment at backend/.venv..."
  "$PYTHON_BIN" -m venv "$VENV_DIR" || fail "Could not create venv. On Debian/Ubuntu try: sudo apt install python3-venv"
  ok "Virtual environment created"
else
  ok "Virtual environment already exists"
fi

VENV_PY="$VENV_DIR/bin/python"
VENV_PIP="$VENV_DIR/bin/pip"
if [ ! -f "$VENV_PY" ]; then
  # Windows venv layout
  VENV_PY="$VENV_DIR/Scripts/python.exe"
  VENV_PIP="$VENV_DIR/Scripts/pip.exe"
fi

# ---------- 3. Python deps ----------
info "Installing Python dependencies (fastapi, uvicorn, yt-dlp, ...)..."
"$VENV_PY" -m pip install --upgrade pip -q
"$VENV_PY" -m pip install -q -r "$BACKEND_DIR/requirements.txt"
ok "Python dependencies installed"

# ---------- 4. ffmpeg ----------
info "Checking for ffmpeg (required to merge video+audio streams)..."
if command -v ffmpeg >/dev/null 2>&1; then
  ok "ffmpeg found: $(command -v ffmpeg)"
else
  warn "ffmpeg not found — attempting to install it..."
  OS="$(uname -s 2>/dev/null || echo unknown)"
  INSTALLED=0
  if [ "$OS" = "Linux" ]; then
    if command -v apt-get >/dev/null 2>&1; then
      info "Detected apt (Debian/Ubuntu). This needs sudo:"
      sudo apt-get update -qq && sudo apt-get install -y ffmpeg -qq && INSTALLED=1
    elif command -v dnf >/dev/null 2>&1; then
      info "Detected dnf (Fedora). This needs sudo:"
      sudo dnf install -y ffmpeg && INSTALLED=1
    elif command -v pacman >/dev/null 2>&1; then
      info "Detected pacman (Arch). This needs sudo:"
      sudo pacman -Sy --noconfirm ffmpeg && INSTALLED=1
    fi
  elif [ "$OS" = "Darwin" ]; then
    if command -v brew >/dev/null 2>&1; then
      info "Detected Homebrew (macOS):"
      brew install ffmpeg && INSTALLED=1
    else
      warn "Homebrew not found. Install it from https://brew.sh, then run: brew install ffmpeg"
    fi
  fi
  if [ "$INSTALLED" -eq 1 ] && command -v ffmpeg >/dev/null 2>&1; then
    ok "ffmpeg installed: $(command -v ffmpeg)"
  else
    warn "Could not auto-install ffmpeg. Install it manually before downloading anything:"
    echo "    Debian/Ubuntu : sudo apt install ffmpeg"
    echo "    Fedora        : sudo dnf install ffmpeg"
    echo "    Arch          : sudo pacman -S ffmpeg"
    echo "    macOS         : brew install ffmpeg"
    echo "    Windows       : choco install ffmpeg   (or download from ffmpeg.org and add to PATH)"
  fi
fi

# ---------- 5. downloads dir ----------
mkdir -p "$BACKEND_DIR/downloads"

echo ""
ok "${BOLD}Setup complete.${RESET}"
echo "  Start manually any time with:"
echo "    ${DIM}source backend/.venv/bin/activate && uvicorn main:app --reload --port 8000 --app-dir backend${RESET}"
echo ""

# ---------- 6. run ----------
start_server() {
  echo ""
  info "Starting server at ${BOLD}http://localhost:8000${RESET} (Ctrl+C to stop)..."
  cd "$BACKEND_DIR"
  exec "$VENV_PY" -m uvicorn main:app --reload --port 8000
}

case "$RUN_MODE" in
  yes) start_server ;;
  no)  ;;
  ask)
    read -r -p "Start the server now? [Y/n] " reply
    case "$reply" in
      [nN]*) ;;
      *) start_server ;;
    esac
    ;;
esac
