# YTDL Studio

A personal-use YouTube/video downloader: paste a URL, pick video or audio,
watch it fetch → download → merge, done. Real backend, real yt-dlp, real
progress — nothing in the current build is simulated.

## How it's built

- **Backend:** Python + FastAPI. Uses `yt-dlp` as a Python library (not
  shelled out to), so its `progress_hooks` / `postprocessor_hooks` fire
  directly in-process during the real download. Each hook event is pushed
  over a **WebSocket** to the browser as it happens — that's what drives
  the live progress bar, speed/ETA, and the switch to the merge animation
  at the right moment.
- **Frontend:** one static HTML file, no build step, no framework. Talks to
  the backend via `fetch` + `WebSocket`.
- **Merging:** when you download "Video" at a quality that isn't already a
  single combined stream, YouTube serves video and audio separately —
  yt-dlp downloads both, then merges them with `ffmpeg -c copy` (no
  re-encode, so it's fast). That's a real postprocessor step, not
  decoration.

## Run it

**Easiest — one command:**

```bash
./setup.sh
```

This creates a `backend/.venv`, installs everything into it, installs ffmpeg
if it can (apt/dnf/pacman/brew), and asks if you want to start the server
right away. Run `./setup.sh --run` to skip the prompt and start immediately,
or `./setup.sh --no-run` to just set up without starting anything.

**Manually, if you'd rather:**

```bash
cd backend
pip install -r requirements.txt
```

You also need **ffmpeg** on your PATH (required for merging separate
video+audio streams, and for audio extraction):

```bash
# Debian/Ubuntu
sudo apt install ffmpeg
# macOS
brew install ffmpeg
# Windows
choco install ffmpeg
```

Then:

```bash
uvicorn main:app --reload --port 8000
```

Open **http://localhost:8000** — the backend serves the frontend directly
(same origin, so no CORS setup needed).

## What actually happens when you click Download

1. `POST /api/probe` — runs `yt_dlp.extract_info(download=False)` to get
   title/thumbnail/duration without downloading.
2. `POST /api/download` — starts a background thread per job, returns a
   `job_id` immediately.
3. The frontend opens `ws://.../ws/jobs/{job_id}`. As yt-dlp downloads the
   video stream, then the audio stream, then merges them, the hooks push
   `{type: "progress", stage: "video"|"audio", pct, speed, eta}` and
   `{type: "stage", stage: "merging"}` events — the frontend just renders
   whatever it receives.
4. On completion the file is saved to `backend/downloads/`, indexed in
   `backend/downloads/_index.json`, and appears in the library. Files are
   served back via `GET /files/{filename}`.

## Endpoints

| Method | Path                | Purpose                                   |
|--------|---------------------|--------------------------------------------|
| POST   | `/api/probe`        | Fetch metadata for one or more URLs        |
| POST   | `/api/download`      | Start a download job → returns `job_id`    |
| WS     | `/ws/jobs/{job_id}`  | Live progress events for a job             |
| GET    | `/api/jobs/{job_id}` | Poll fallback / reconnect state            |
| GET    | `/api/library`       | List downloaded files                      |
| GET    | `/files/{filename}`  | Download a saved file                      |
| POST   | `/api/cookies`       | Upload `cookies.txt` (bypasses age-gates)  |
| DELETE | `/api/cookies`       | Remove stored cookies                      |

## Known limitations / things worth doing next

- **Jobs are in-memory.** Restarting the backend loses in-flight job state
  (finished downloads are safe — they're indexed on disk). Fine for a
  personal tool; swap in Redis/SQLite if this ever needs to survive restarts
  or run with multiple workers.
- **`noplaylist: True`** — a playlist URL currently downloads just the first
  video. Flip that flag and loop `extract_info`'s `entries` in `/api/probe`
  if you want full playlist support (the "1 of 1" → "1 of N" UI already
  supports multiple items, it's just not fed a playlist yet).
- **No auth/rate limiting.** This is built for local/personal use. Don't
  expose it to the open internet as-is — add auth if you deploy it
  somewhere reachable by others.
- **Merge progress is a fixed animation, not a real percentage.** `ffmpeg
  -c copy` (stream copy, no re-encode) is fast enough that yt-dlp doesn't
  give fine-grained merge progress — so the merge visualization plays a
  timed animation rather than fabricating a fake %. If you switch to
  re-encoding, ffmpeg progress can be parsed for a real bar.
- I could not test an actual YouTube download end-to-end from the
  environment I built this in (its network is locked to package
  registries). The full pipeline — job creation, hook → WebSocket event
  flow, library indexing, file serving — is verified with `yt-dlp` mocked
  out (`tests/test_pipeline.py`); the one untested link is the real
  network call to YouTube itself. Worth running one real download early to
  confirm your yt-dlp version handles current YouTube's format list
  correctly (this changes periodically on YouTube's end and old yt-dlp
  versions occasionally lag behind — `pip install -U yt-dlp` if a fetch
  fails).

## Tests

```bash
cd backend
pip install httpx  # test-only dependency
python ../tests/test_hooks.py     # unit: hook state machine (video→audio→merge)
python ../tests/test_pipeline.py  # integration: full job lifecycle, yt-dlp mocked
```
