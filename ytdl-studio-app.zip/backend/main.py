"""
YTDL Studio — backend.

Wraps yt-dlp (used as a Python library, not shelled out to) behind a small
FastAPI app. yt-dlp's progress_hooks / postprocessor_hooks fire from a
background thread during the real download+merge, and each event is pushed
over a WebSocket to the browser in real time — that's what drives the
progress bar, speed/ETA numbers, and the video/audio/merge stage switch on
the frontend. Nothing here is simulated.

Run:
    pip install -r requirements.txt
    # ffmpeg must be on PATH (needed for yt-dlp to merge separate
    # video+audio streams into one file) — `apt install ffmpeg` /
    # `brew install ffmpeg` / choco on Windows.
    uvicorn main:app --reload --port 8000

Then open http://localhost:8000
"""

from __future__ import annotations

import asyncio
import json
import os
import re
import threading
import time
import uuid
from pathlib import Path
from typing import Any

import yt_dlp
from fastapi import FastAPI, UploadFile, WebSocket, WebSocketDisconnect
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

BASE_DIR = Path(__file__).parent
DOWNLOAD_DIR = BASE_DIR / "downloads"
COOKIES_PATH = BASE_DIR / "cookies.txt"
LIBRARY_INDEX = DOWNLOAD_DIR / "_index.json"
DOWNLOAD_DIR.mkdir(exist_ok=True)

app = FastAPI(title="YTDL Studio API")

# ---------------------------------------------------------------------------
# In-memory job store. A personal/local utility doesn't need a database —
# jobs live for the life of the process. Each job tracks the current stage
# so a client reconnecting mid-job (e.g. page refresh) can catch up via
# GET /api/jobs/{id} before/instead of opening the WebSocket.
# ---------------------------------------------------------------------------
JOBS: dict[str, dict[str, Any]] = {}
SUBSCRIBERS: dict[str, list[asyncio.Queue]] = {}


def _library() -> list[dict]:
    if LIBRARY_INDEX.exists():
        return json.loads(LIBRARY_INDEX.read_text())
    return []


def _save_library(entries: list[dict]) -> None:
    LIBRARY_INDEX.write_text(json.dumps(entries, indent=2))


def _push(job_id: str, payload: dict) -> None:
    """Record an event on the job and fan it out to any live subscribers."""
    job = JOBS.get(job_id)
    if job is None:
        return
    job["logs"].append(payload)
    job["logs"] = job["logs"][-200:]
    for k, v in payload.items():
        if k in ("stage", "pct", "speed", "eta", "item_index", "item_total"):
            job[k] = v
    for q in SUBSCRIBERS.get(job_id, []):
        q.put_nowait(payload)


def _push_threadsafe(loop: asyncio.AbstractEventLoop, job_id: str, payload: dict) -> None:
    loop.call_soon_threadsafe(_push, job_id, payload)


# ---------------------------------------------------------------------------
# yt-dlp option building
# ---------------------------------------------------------------------------

QUALITY_FORMATS = {
    "Best Available": "bestvideo*+bestaudio/best",
    "1080p": "bestvideo[height<=1080]+bestaudio/best[height<=1080]",
    "720p": "bestvideo[height<=720]+bestaudio/best[height<=720]",
    "480p": "bestvideo[height<=480]+bestaudio/best[height<=480]",
}


def build_opts(kind: str, quality: str, job_id: str, item_index: int,
                loop: asyncio.AbstractEventLoop) -> dict:
    seen_finished: set[str] = set()

    def progress_hook(d: dict) -> None:
        status = d.get("status")
        job = JOBS[job_id]
        if status == "downloading":
            downloaded = d.get("downloaded_bytes") or 0
            total = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
            pct = round(downloaded / total * 100, 1) if total else 0.0
            speed = d.get("speed")
            speed_s = f"{speed / 1024 / 1024:.1f} MB/s" if speed else "--"
            eta = d.get("eta")
            eta_s = f"00:{int(eta):02d}" if isinstance(eta, (int, float)) and eta < 3600 else "--:--"
            stage = job.get("stage")
            if stage in ("queued", "probing", None):
                stage = "video" if kind == "video" else "audio"
            _push_threadsafe(loop, job_id, {
                "type": "progress", "stage": stage, "pct": pct,
                "speed": speed_s, "eta": eta_s,
                "item_index": item_index, "item_total": job["item_total"],
            })
        elif status == "finished":
            fname = d.get("filename", "")
            if fname not in seen_finished:
                seen_finished.add(fname)
                _push_threadsafe(loop, job_id, {
                    "type": "log", "tag": "ok",
                    "msg": f"Saved {os.path.basename(fname)}",
                })
            # bestvideo+bestaudio downloads two streams sequentially; once
            # the first finishes we're onto the second (audio) pass.
            if job.get("stage") == "video":
                job["stage"] = "audio"

    def pp_hook(d: dict) -> None:
        pp = d.get("postprocessor", "")
        status = d.get("status")
        job = JOBS[job_id]
        if "Merger" in pp and status == "started":
            job["stage"] = "merging"
            _push_threadsafe(loop, job_id, {"type": "stage", "stage": "merging"})
            _push_threadsafe(loop, job_id, {
                "type": "log", "tag": "merge",
                "msg": "ffmpeg -i video -i audio -c copy output.mp4",
            })
        elif "Merger" in pp and status == "finished":
            _push_threadsafe(loop, job_id, {
                "type": "log", "tag": "ok", "msg": "Merge complete.",
            })

    opts: dict[str, Any] = {
        "outtmpl": str(DOWNLOAD_DIR / "%(title).150B [%(id)s].%(ext)s"),
        "progress_hooks": [progress_hook],
        "postprocessor_hooks": [pp_hook],
        "noplaylist": True,
        "quiet": True,
        "no_warnings": True,
        "restrictfilenames": False,
        "windowsfilenames": True,
    }
    if kind == "audio":
        opts["format"] = "bestaudio/best"
        opts["postprocessors"] = [{
            "key": "FFmpegExtractAudio", "preferredcodec": "mp3", "preferredquality": "192",
        }]
    else:
        opts["format"] = QUALITY_FORMATS.get(quality, QUALITY_FORMATS["Best Available"])
        opts["merge_output_format"] = "mp4"

    if COOKIES_PATH.exists():
        opts["cookiefile"] = str(COOKIES_PATH)

    return opts


def run_job(job_id: str, items: list[dict], kind: str, quality: str,
            loop: asyncio.AbstractEventLoop) -> None:
    job = JOBS[job_id]
    job["item_total"] = len(items)
    entries = _library()
    try:
        for idx, item in enumerate(items, start=1):
            job["stage"] = "video" if kind == "video" else "audio"
            _push_threadsafe(loop, job_id, {
                "type": "log", "tag": "info",
                "msg": f"Downloading {item['url']} as {kind}.",
            })
            before = {p.name for p in DOWNLOAD_DIR.glob("*") if p.suffix != ".json"}
            opts = build_opts(kind, quality, job_id, idx, loop)
            with yt_dlp.YoutubeDL(opts) as ydl:
                info = ydl.extract_info(item["url"], download=True)
            after = {p.name for p in DOWNLOAD_DIR.glob("*") if p.suffix != ".json"}
            new_files = [f for f in (after - before) if not f.endswith((".part", ".ytdl"))]
            final_name = new_files[0] if new_files else None
            size = (DOWNLOAD_DIR / final_name).stat().st_size if final_name else 0
            entry = {
                "id": str(uuid.uuid4()),
                "title": info.get("title", item.get("title", "Untitled")),
                "filename": final_name,
                "kind": kind,
                "duration": info.get("duration"),
                "thumbnail": info.get("thumbnail"),
                "size_bytes": size,
                "downloaded_at": time.time(),
            }
            entries.insert(0, entry)
            _save_library(entries)
            _push_threadsafe(loop, job_id, {"type": "item_done", "entry": entry})
        job["status"] = "done"
        _push_threadsafe(loop, job_id, {"type": "done"})
    except Exception as e:  # yt-dlp raises plain Exceptions/DownloadError
        job["status"] = "error"
        _push_threadsafe(loop, job_id, {"type": "error", "msg": str(e)})


# ---------------------------------------------------------------------------
# API
# ---------------------------------------------------------------------------

def _split_urls(raw: str) -> list[str]:
    parts = re.split(r"[\n,]+", raw)
    return [p.strip() for p in parts if p.strip()]


@app.post("/api/probe")
async def probe(payload: dict):
    urls = _split_urls(payload.get("urls", ""))
    if not urls:
        return JSONResponse({"error": "No URLs given"}, status_code=400)

    def _extract():
        opts = {"quiet": True, "no_warnings": True, "noplaylist": True, "skip_download": True}
        if COOKIES_PATH.exists():
            opts["cookiefile"] = str(COOKIES_PATH)
        items = []
        with yt_dlp.YoutubeDL(opts) as ydl:
            for url in urls:
                info = ydl.extract_info(url, download=False)
                items.append({
                    "url": url,
                    "title": info.get("title"),
                    "duration": info.get("duration"),
                    "thumbnail": info.get("thumbnail"),
                    "uploader": info.get("uploader"),
                })
        return items

    try:
        items = await asyncio.to_thread(_extract)
    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=422)
    return {"items": items}


@app.post("/api/download")
async def download(payload: dict):
    items = payload.get("items", [])
    kind = payload.get("format", "video")
    quality = payload.get("quality", "Best Available")
    if not items:
        return JSONResponse({"error": "No items to download"}, status_code=400)

    job_id = str(uuid.uuid4())
    JOBS[job_id] = {"status": "running", "stage": "queued", "logs": [], "item_total": len(items)}
    SUBSCRIBERS[job_id] = []
    loop = asyncio.get_running_loop()
    threading.Thread(target=run_job, args=(job_id, items, kind, quality, loop), daemon=True).start()
    return {"job_id": job_id}


@app.get("/api/jobs/{job_id}")
async def job_status(job_id: str):
    job = JOBS.get(job_id)
    if not job:
        return JSONResponse({"error": "unknown job"}, status_code=404)
    return job


@app.websocket("/ws/jobs/{job_id}")
async def job_ws(ws: WebSocket, job_id: str):
    await ws.accept()
    if job_id not in JOBS:
        await ws.send_json({"type": "error", "msg": "unknown job"})
        await ws.close()
        return
    q: asyncio.Queue = asyncio.Queue()
    SUBSCRIBERS.setdefault(job_id, []).append(q)
    for evt in JOBS[job_id]["logs"]:
        await ws.send_json(evt)
    try:
        while True:
            evt = await q.get()
            await ws.send_json(evt)
            if evt.get("type") in ("done", "error"):
                break
    except WebSocketDisconnect:
        pass
    finally:
        SUBSCRIBERS.get(job_id, []).remove(q)


@app.get("/api/library")
async def library():
    return {"items": _library()}


@app.get("/files/{filename}")
async def get_file(filename: str):
    path = DOWNLOAD_DIR / filename
    if not path.exists():
        return JSONResponse({"error": "not found"}, status_code=404)
    return FileResponse(path, filename=filename)


@app.post("/api/cookies")
async def upload_cookies(file: UploadFile):
    data = await file.read()
    COOKIES_PATH.write_bytes(data)
    return {"ok": True, "filename": file.filename}


@app.delete("/api/cookies")
async def clear_cookies():
    COOKIES_PATH.unlink(missing_ok=True)
    return {"ok": True}


# Serve the frontend from the same origin — avoids CORS entirely.
FRONTEND_DIR = BASE_DIR.parent / "frontend"
if FRONTEND_DIR.exists():
    app.mount("/", StaticFiles(directory=str(FRONTEND_DIR), html=True), name="frontend")
