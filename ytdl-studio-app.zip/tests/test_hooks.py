import asyncio
import sys
sys.path.insert(0, ".")
import main

async def run():
    job_id = "test-job"
    main.JOBS[job_id] = {"status": "running", "stage": "queued", "logs": [], "item_total": 1}
    main.SUBSCRIBERS[job_id] = []
    q = asyncio.Queue()
    main.SUBSCRIBERS[job_id].append(q)
    loop = asyncio.get_running_loop()

    opts = main.build_opts("video", "Best Available", job_id, 1, loop)
    progress_hook = opts["progress_hooks"][0]
    pp_hook = opts["postprocessor_hooks"][0]

    # simulate: downloading video stream
    progress_hook({"status": "downloading", "downloaded_bytes": 5_000_000,
                    "total_bytes": 20_000_000, "speed": 2_500_000, "eta": 6})
    await asyncio.sleep(0)
    evt = q.get_nowait()
    assert evt["stage"] == "video", evt
    assert evt["pct"] == 25.0, evt
    print("video progress event OK:", evt)

    # simulate: video stream finished -> stage should flip to audio
    progress_hook({"status": "finished", "filename": "downloads/foo.f137.mp4"})
    await asyncio.sleep(0)
    evt = q.get_nowait()
    assert evt["type"] == "log" and evt["tag"] == "ok", evt
    assert main.JOBS[job_id]["stage"] == "audio"
    print("stage flip video->audio OK")

    # simulate: downloading audio stream
    progress_hook({"status": "downloading", "downloaded_bytes": 1_000_000,
                    "total_bytes": 2_000_000, "speed": 800_000, "eta": 1})
    await asyncio.sleep(0)
    evt = q.get_nowait()
    assert evt["stage"] == "audio", evt
    print("audio progress event OK:", evt)

    # simulate: merger postprocessor starts -> stage should become merging
    pp_hook({"postprocessor": "Merger", "status": "started"})
    await asyncio.sleep(0)
    evt = q.get_nowait()
    assert evt == {"type": "stage", "stage": "merging"}, evt
    assert main.JOBS[job_id]["stage"] == "merging"
    print("merge stage event OK:", evt)
    evt2 = q.get_nowait()
    assert evt2["type"] == "log" and evt2["tag"] == "merge"
    print("merge log event OK:", evt2)

    pp_hook({"postprocessor": "Merger", "status": "finished"})
    await asyncio.sleep(0)
    evt = q.get_nowait()
    assert evt["type"] == "log" and evt["tag"] == "ok" and "Merge complete" in evt["msg"]
    print("merge finished log OK:", evt)

    print("\nALL HOOK LOGIC ASSERTIONS PASSED")

asyncio.run(run())
