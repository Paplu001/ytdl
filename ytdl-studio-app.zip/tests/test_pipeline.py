import sys, json
sys.path.insert(0, ".")
from unittest.mock import patch, MagicMock
from fastapi.testclient import TestClient
import main

class FakeYDL:
    def __init__(self, opts):
        self.opts = opts
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def extract_info(self, url, download=True):
        hooks = self.opts.get("progress_hooks", [])
        pp_hooks = self.opts.get("postprocessor_hooks", [])
        # write the fake output file yt-dlp would have produced
        out = main.DOWNLOAD_DIR / "Test Video [abc123].mp4"
        out.write_bytes(b"x" * 1024 * 1024)  # 1 MB fake file
        for h in hooks:
            h({"status": "downloading", "downloaded_bytes": 500_000, "total_bytes": 1_000_000, "speed": 900_000, "eta": 1})
            h({"status": "finished", "filename": str(main.DOWNLOAD_DIR / "video_only.f137.mp4")})
            h({"status": "downloading", "downloaded_bytes": 100_000, "total_bytes": 200_000, "speed": 400_000, "eta": 1})
            h({"status": "finished", "filename": str(main.DOWNLOAD_DIR / "audio_only.f140.m4a")})
        for h in pp_hooks:
            h({"postprocessor": "Merger", "status": "started"})
            h({"postprocessor": "Merger", "status": "finished"})
        return {"title": "Test Video", "duration": 125, "thumbnail": "https://example.com/t.jpg"}

client = TestClient(main.app)

with patch("main.yt_dlp.YoutubeDL", FakeYDL):
    r = client.post("/api/download", json={
        "items": [{"url": "https://youtu.be/fake123", "title": "Test Video"}],
        "format": "video", "quality": "Best Available",
    })
    assert r.status_code == 200, r.text
    job_id = r.json()["job_id"]
    print("job created:", job_id)

    import time
    time.sleep(0.3)  # let the background thread run (it's fast since YDL is fake)

    with client.websocket_connect(f"/ws/jobs/{job_id}") as ws:
        events = []
        while True:
            evt = ws.receive_json()
            events.append(evt)
            if evt["type"] in ("done", "error"):
                break

types_seen = [e["type"] for e in events]
print("event sequence:", types_seen)
assert "progress" in types_seen
assert any(e.get("stage") == "merging" for e in events if e["type"] == "stage"), events
assert "item_done" in types_seen
assert types_seen[-1] == "done"
print("\nFull event log:")
for e in events:
    print(" ", e)

# verify library + file serving
r = client.get("/api/library")
lib = r.json()["items"]
assert len(lib) == 1, lib
entry = lib[0]
print("\nlibrary entry:", entry)
assert entry["title"] == "Test Video"
assert entry["filename"] == "Test Video [abc123].mp4"

r = client.get(f"/files/{entry['filename']}")
assert r.status_code == 200
assert len(r.content) == 1024 * 1024
print("\nfile served correctly, size:", len(r.content), "bytes")

print("\nFULL PIPELINE INTEGRATION TEST PASSED")
